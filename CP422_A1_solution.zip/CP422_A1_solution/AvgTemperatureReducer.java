package avgTemp;

import java.io.IOException;
import java.lang.Math;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class AvgTemperatureReducer
extends Reducer<Text, IntWritable, Text, IntWritable> {

@Override
public void reduce(Text key, Iterable<IntWritable> values,
   Context context)
   throws IOException, InterruptedException {
    
    int sumValue = 0;
    int count = 0;
    float avgValue;
    int avg_temp = 0;

    for (IntWritable value : values) {
      sumValue = sumValue + value.get();
      count = count + 1;
    }
    
    avgValue = sumValue/count;
    avg_temp = Math.round(avgValue);
    context.write(key, new IntWritable(avg_temp));
  }

}

